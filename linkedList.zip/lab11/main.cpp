#include <iostream>



struct Node {
    int data;
    Node *next;

    Node(int data, Node  *next = nullptr): data(data), next(next) {}
};

class LinkedList {
    private:
    Node *head;

    public:
    LinkedList(): head(nullptr) {}


    ~LinkedList() {
        auto current = head;

        while (current != nullptr) {
            auto next = current->next;
            delete current;
            current = next;
        }

        head = nullptr;

    }





    Node *getHead() const { return head;}



void pushFront(int item) {
    
    Node *node = new Node(item);

    if (head == nullptr) {

        head = node;

        return;
    }

    node->next = head;
    head = node;
}

void pushBack(int item) {

    Node *node = new Node(item);

    if (head == nullptr) {
        head = node;
        return;
    }

    auto current = head;

    while (current->next != nullptr) {
        current = current->next;
    }

    current->next = node;

}


bool contains(int item) {
    auto current = head;

    while (current != nullptr) {
        if (current->data == item) {
            return true;
        }

        current = current->next;
    }
    return false;
}

void deleteItem(int item) {
    Node *curr = head;
    Node *prev = nullptr;

    if (curr == nullptr) {
 return;
 }
 if (curr->data == item) {
 head = curr->next;
 delete curr;
 return;
 }

    while (curr != nullptr) {
        if (curr->data == item) {
            if (prev == nullptr) {
                head = curr->next;
                return;
            }
                    
                    
            prev->next = curr->next;
            delete curr;
            return;
        }
        prev = curr;
        curr = curr->next;

    }
}

int size() {

    Node *curr = head;

    int count = 0;

    if (curr == nullptr) {
        return count;
    }

   
    while (curr != nullptr) {
        curr = curr->next;
        count++;
    }

        return count;
}

int countItem(int item) {

    Node *curr = head;
    int count = 0;

    while (curr != nullptr) {
        if (curr->data == item) {
            
            count++;
        }
        curr = curr->next;
    }

        return count;

}

void removeDuplicates() {
    Node *curr = head;

    while (curr != nullptr && curr->next != nullptr) {
        if (curr->data == curr->next->data) {

            Node *temp = curr->next;
            curr->next = curr->next->next;
            delete temp;
        }
        curr = curr->next;
    }

}

};


std::ostream& operator<<(std::ostream &os, const LinkedList &ll) {
    auto current = ll.getHead();

    while (current != nullptr) {
    os << current->data << " -> ";
    current = current->next;
    }

    os << "nullptr";

    return os;
}


int main() {
    LinkedList list;

    list.pushFront(10);
    list.pushFront(5);
    list.pushBack(15);
    list.pushBack(20);
    list.pushBack(10);
    list.pushBack(10);

    std::cout << list << std::endl;

    std::cout << "Size: " << list.size() << std::endl;
    std::cout << "Contains 10: " << list.contains(10) << std::endl;
    std::cout << "Contains 99: " << list.contains(99) << std::endl;
    std::cout << "Count of 10: " << list.countItem(10) << std::endl;

    list.removeDuplicates();
    std::cout << list << std::endl;

    list.deleteItem(15);
    std::cout << list << std::endl;

    list.deleteItem(5);
    std::cout << list << std::endl;

    std::cout << "Size: " << list.size() << std::endl;

    return 0;
}